package com.OCS.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.OCS.model.AppointmentSchedule;
import com.OCS.model.Doctor;
import com.OCS.model.Patient;
import com.OCS.service.AppointmentService;
import com.OCS.service.DoctorService;
import com.OCS.service.PatientService;
@Controller
public class PatientController {

	@Autowired
	private PatientService patientService;
	
	@Autowired
	private DoctorService doctorService;
	
	@Autowired
	AppointmentService appointmentService;
	
	@Autowired
	private HttpSession s;

	@GetMapping("/Doctor")
	public String displayDoctor()
	{
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		return "Doctor";
	}
	@GetMapping("/Doctorview")
	public String displaydoctorview()
	{
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		return "Doctor";
	}
	@GetMapping("/alldoctorview")
	public String viewdoctor(Model model) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		List<Doctor> doctor = doctorService.findDoc();
		model.addAttribute("doctor",doctor);
		return "viewdoctor";
	}
	@GetMapping("/search")
	public String displayBySpl(@RequestParam("specialization") String spl,Model model)
	{
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		List<Doctor> list=doctorService.listDoctors(spl);
		model.addAttribute("doctor",list);
		System.out.println(list);
		return "viewdoctor";
	}
	
		
	
	@GetMapping("/up")
	public String updatedetials(@RequestParam("email") String email,Model model) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		Patient patient=patientService.getPatient(email);
		model.addAttribute("users",patient);
		return "UpdateDetails";
	}
	@PostMapping("/update")
	public String updatepatient( Patient pt, Model model) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		patientService.SavePatient(pt);
		return "home";
	}
	@GetMapping("/changepass")
	public String changepass(@RequestParam("email")String email , Model model) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		Patient p=patientService.getPatient(email);
		model.addAttribute("email",p.getEmail());
		model.addAttribute("passr",p.getPassword());
		return "changepass";
	}

	@PostMapping("/changepassword")
	public String changepassword(@RequestParam("email") String email ,@RequestParam("password") String password ,@RequestParam("oldpassword") String old) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		Patient p=patientService.getPatient(email);
		if(old.equals(p.getPassword()) && !password.equals(old))
		{
		p.setPassword(password);
		patientService.SavePatient(p);
		return "home";
		}
		return "changepass";
	}
	
	@GetMapping("/Appointment")
	public String getAppointment(Model m) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		return "Appointment";
	}
	@GetMapping("/book")
	public String appoint(@RequestParam Integer id, Model model) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		model.addAttribute("id",id);
		return "Appointment";
	}
	@PostMapping("/book")
	public String appointment( AppointmentSchedule appoint,Model model,@RequestParam Integer did,HttpSession sess) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		Doctor d=doctorService.getById(did);
		String email=(String) sess.getAttribute("email");
		Patient p=patientService.getPatient(email);
			appoint.setPt(p);
			appoint.setDr(d);
			appointmentService.Appointmentsave(appoint);
		return "home";
		
	}
	@GetMapping("/viewap")
	public String appointment2( @RequestParam("email") String email  ,Model m) {
		if(s.getAttribute("auth")==null) {
			return "error";
		}
		Patient p=patientService.getPatient(email);
			List<AppointmentSchedule> a=appointmentService.getAll(p.getUserID());
			m.addAttribute("a", a);
		return "viewap";
		
	}
}
	
	
	

