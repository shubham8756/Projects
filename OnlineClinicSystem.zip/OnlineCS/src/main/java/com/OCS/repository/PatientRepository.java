package com.OCS.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.OCS.model.Patient;

public interface PatientRepository extends JpaRepository<Patient, Integer>{
		public Patient findByEmail(String email);
		public Patient getById(Integer userID);
}
