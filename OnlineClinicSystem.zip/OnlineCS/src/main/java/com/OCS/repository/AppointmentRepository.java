package com.OCS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.OCS.model.AppointmentSchedule;

public interface AppointmentRepository extends JpaRepository<AppointmentSchedule, Integer>{
	@Query("from com.OCS.model.AppointmentSchedule where pt.userID=:pat")
public List<AppointmentSchedule> get(Integer pat);
}