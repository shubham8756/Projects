package com.OCS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OCS.model.Patient;
import com.OCS.repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patientRepository;
	
	
	public boolean authenticate(String email, String password) {
	    Patient patient = patientRepository.findByEmail(email);
	    if (patient != null && patient.getPassword().equals(password)) {
	      return true;
	    }
	    return false;
	  }
	public Patient getPatient(String email) {
		  return patientRepository.findByEmail(email);
		  
	}
	public Patient getPatientById(Integer userID) {
		return patientRepository.getById(userID);
	}
	
	public void SavePatient(Patient patient) {
		patientRepository.save(patient);
	}
	public boolean checkPatient(String email) {
		if(patientRepository.findByEmail(email)!=null)
			return true;
		return false;
	}

}
