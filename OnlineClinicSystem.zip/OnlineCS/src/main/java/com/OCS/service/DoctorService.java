package com.OCS.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OCS.model.Doctor;
import com.OCS.repository.DoctorRepository;

@Service
public class DoctorService {

@Autowired
private DoctorRepository doctorRepository;


public List<Doctor> listDoctors (String spl){
	
	return doctorRepository.findBySpecialization(spl);
	
	
}


public List<Doctor> findDoc() {
	// TODO Auto-generated method stub
	return doctorRepository.findAll();
	

}
public Doctor getById(Integer id) {
	return doctorRepository.findById(id).get();
}


}
