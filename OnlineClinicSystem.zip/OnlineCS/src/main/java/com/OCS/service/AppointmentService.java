package com.OCS.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OCS.model.AppointmentSchedule;
import com.OCS.repository.AppointmentRepository;

@Service
public class AppointmentService {
@Autowired
AppointmentRepository appointment;
public String Appointmentsave(AppointmentSchedule appoint) {
	appointment.save(appoint);
	return "";
}
public List<AppointmentSchedule> getAll(Integer UserID){
	return appointment.get(UserID);
}


}
