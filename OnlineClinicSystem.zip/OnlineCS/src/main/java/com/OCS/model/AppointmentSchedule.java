package com.OCS.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.*;


@Entity
public class AppointmentSchedule {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer appointmentID;
	@ManyToOne
	private Patient pt;
	@ManyToOne
	private Doctor dr;
	private LocalDate date;
	private LocalTime time;
	private String symptoms;
	public Integer getAppointmentID() {
		return appointmentID;
	}
	public void setAppointmentID(Integer appointmentID) {
		this.appointmentID = appointmentID;
	}
	public Patient getPt() {
		return pt;
	}
	public void setPt(Patient pt) {
		this.pt = pt;
	}
	public Doctor getDr() {
		return dr;
	}
	public void setDr(Doctor dr) {
		this.dr = dr;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date=	LocalDate.parse(date);
	
	}
	public LocalTime getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time=LocalTime.parse(time);
	
	}
	public String getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

}
