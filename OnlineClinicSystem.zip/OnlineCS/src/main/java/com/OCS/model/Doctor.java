package com.OCS.model;

import javax.persistence.*;



@Entity
public class Doctor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer doctorid;
	
	private String doctor_name;
	
	private String gender;
	
	private String specialization;
	
	private String address;
	
	private long contact;

	public Doctor() {
	
	}

	public Doctor(String doctor_name, String gender, String specialization, String address, long contact) {
		super();
		this.doctor_name = doctor_name;
		this.gender = gender;
		this.specialization = specialization;
		this.address = address;
		this.contact = contact;
	}

	public Integer getDoctorid() {
		return doctorid;
	}

	public void setDoctorid(Integer doctorid) {
		this.doctorid = doctorid;
	}

	public String getDoctor_name() {
		return doctor_name;
	}

	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}
	
	
}
	
	