package com.wipro.ResourceBlocker.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
	
	

@Entity
public class Resource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "rname")
    private String rname;
    
    @Column(unique = true)
    private String resId;

    @Column(name = "rtype")
    private String rtype;

    @Column(name = "location")
    private String location;

    @Column(name = "capacity")
    private int capacity;

    
    
    
	public String getResId() {
		return resId;
	}

	public void setResId(String resId) {
		this.resId = resId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getRtype() {
		return rtype;
	}

	public void setRtype(String rtype) {
		this.rtype = rtype;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	

	public Resource(String rname, String resId, String rtype, String location, int capacity) {
		super();
		this.rname = rname;
		this.resId = resId;
		this.rtype = rtype;
		this.location = location;
		this.capacity = capacity;
	}

	public Resource() {
		super();
	}

    
    
    
       
}












