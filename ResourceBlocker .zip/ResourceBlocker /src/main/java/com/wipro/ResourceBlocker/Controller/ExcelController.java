package com.wipro.ResourceBlocker.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import com.wipro.ResourceBlocker.ServiceImpl.ExcelService;
import jakarta.servlet.http.HttpServletResponse;
@Controller
public class ExcelController {
	@Autowired
	private ExcelService reportService;
	
	@GetMapping("/excel")
	public void generateExcelReport(HttpServletResponse response) throws Exception{
		
		response.setContentType("application/octet-stream");
		
		String headerKey = "Content-Disposition";
		String headerValue = "attachment;filename=Requests.xls";

		response.setHeader(headerKey, headerValue);
		
		reportService.generateExcel(response);
		
		response.flushBuffer();

}


}
