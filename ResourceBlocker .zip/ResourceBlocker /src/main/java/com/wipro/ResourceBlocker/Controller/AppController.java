package com.wipro.ResourceBlocker.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.ResourceBlocker.Entity.Resource;
import com.wipro.ResourceBlocker.Entity.User;

import com.wipro.ResourceBlocker.ServiceImpl.ResourceServiceImpl;
import com.wipro.ResourceBlocker.ServiceImpl.UserServiceImpl;

import jakarta.servlet.http.HttpSession;

//import net.codejava.UserRepository;

@Controller
public class AppController {
    
	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	ResourceServiceImpl resourceServiceImpl;
	@Autowired
	HttpSession htsession;
	
	
	@GetMapping("/")
	public String viewHomePage() {
		return "index";
	}
	@GetMapping("/index")
	public String viewIndexPage() {
		return "index";
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)

	public String loginPage() {

	return "login";

	}
	@RequestMapping(value="/login",method=RequestMethod.POST)

	public String welcomeAdminPage(ModelMap model,@RequestParam("email") String email,@RequestParam String password,HttpSession session){

	User user=userServiceImpl.getUser(email);


	if(user!=null && user.getPassword().equals(password)) {
	session.setAttribute("email", email);
	return "welcome";

	}

	model.put("errorMsg","Please provide the correct email and password");

	return "login";

	}
	
	@RequestMapping(value="/signup",method=RequestMethod.GET)

	public String signup() {

	return "signup";

	}



	@RequestMapping(value="/signup",method=RequestMethod.POST)

	public String addUser(@ModelAttribute User user) {

	userServiceImpl.save(user);

	return "redirect:/welcome";

	}

	

//
    @RequestMapping(value = "/reservation", method = RequestMethod.GET)
    public String showForm(Model model) {
    	System.out.println(htsession.getAttribute("email"));
    	if(htsession.getAttribute("email")==null)
		{
			return "error";
		}
    	Resource resource=new Resource();
        model.addAttribute("resource",resource);
        return "reservation";
    }

    @RequestMapping(value = "/reservation", method = RequestMethod.POST)
    public String submitForm(@ModelAttribute("resource") Resource resource) {
    	System.out.println(htsession.getAttribute("email"));
    	System.out.println(htsession.getAttribute("email"));
    	if(htsession.getAttribute("email")==null)
		{
			return "error";
		}
    	
         resourceServiceImpl.save(resource);
        return "redirect:/welcome";
    }
    
	
    
    @GetMapping("/welcome")
    public String home1() {
    	System.out.println(htsession.getAttribute("email"));
    	

    	
        return "welcome";
    }
    

	
	
    @GetMapping("/view")
    public String viewResources(Model model) {
    	
    	if(htsession.getAttribute("email")==null)
		{
			return "error";
		}
    	
    	
    	
//    	Resource resource=new Resource();
      List<Resource> resources = resourceServiceImpl.getAllResource();
      model.addAttribute("resources", resources);
      return "view";
    }
    

	
    
//   
    
    
    
    
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String deleteResource(@RequestParam("id") Long id) {
        resourceServiceImpl.deleteResource(id);
        return "redirect:/view";
    }
    
    
    
    @RequestMapping(value = "/updateResource", method = RequestMethod.POST)
    public String editResource(@RequestParam("id") Long id,Model model) {
    	if(htsession.getAttribute("email")==null)
		{
			return "error";
		}
    	
    	Resource resource = resourceServiceImpl.getResourceById(id);
    	model.addAttribute("resource", resource);
    	resourceServiceImpl.updateResource(resource);
    	return "update_Resource";
    	
    }
    
    
    @GetMapping("/changePass")
    public String changePass(@RequestParam("email") String email, HttpSession session)
    {	
    	
    	session.setAttribute("email", email);
    return "changePass" ;
    }
    @PostMapping("/save-pass")
    public String savePass(@RequestParam("password") String password,@RequestParam("email") String email)

    {

    	
    	System.out.println(email);
    	
    	User user= userServiceImpl.getUser(email);
    	user.setPassword(password);
    	userServiceImpl.save(user);
    	return "login";
    }
    
    
//    
     
    
    
    
    @RequestMapping(value="/updt", method=RequestMethod.POST)
    public String updateResource(@ModelAttribute("resource") Resource resource, Model model ) {

    	//get resource from database
//    	
    	resourceServiceImpl.updateResource(resource);
    	return "redirect:/view";
    	
    }
    
    @GetMapping("/logout")
    public String logout()
    {
    	htsession.invalidate();
    	return "index";
    }
    

//	
	

}
