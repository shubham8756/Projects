package com.wipro.ResourceBlocker.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.ResourceBlocker.Entity.Request;
import com.wipro.ResourceBlocker.Entity.Resource;
import com.wipro.ResourceBlocker.ServiceImpl.RequestServiceImpl;
import com.wipro.ResourceBlocker.ServiceImpl.ResourceServiceImpl;


import jakarta.servlet.http.HttpSession;

@Controller
public class requestController {
	
	@Autowired
	HttpSession htsession;
	
	@Autowired
	RequestServiceImpl requestServiceImpl;
	
	@Autowired
	ResourceServiceImpl resourceServiceImpl;
	
	@GetMapping("/Employee")
    public String viewRequest(Model model) {
//    	Resource resource=new Resource();
      List<Request> request = requestServiceImpl.getAllRequest();
      model.addAttribute("request", request);
      return "Employee";
    }
	
	
    @RequestMapping(value = "/employee/rejected", method = RequestMethod.POST)
    public String deleteRequest(@RequestParam("id") Long id) {
    	
        //requestServiceImpl.deleteRequest(id);
        return "redirect:/Employee";
    }
    
    
// 
    
    
    
    
    
    
    @GetMapping("/employee/accept")
    public String acceptResource(@RequestParam("id") Long requestId) {
        // Retrieve the resource from the database based on the given ID
        Request req = requestServiceImpl.getRequestById(requestId);
        // Update the resource data as needed (subtract quantity from capacity and set quantity to 0)
        String resId=req.getResId();
        int quant=req.getQuantity();
        Resource resource= resourceServiceImpl.findByResId(resId);
        int capacity= resource.getCapacity();
        resource.setCapacity(capacity-quant);
        
        System.out.println(quant+"  "+capacity+" " );
        resourceServiceImpl.save(resource);
        quant=0;
        req.setStatus("Accepted");
        req.setQuantity(quant);
        requestServiceImpl.updateRequest(req);
        return "redirect:/Employee";
    }
    
    
    
    @GetMapping("/employee/reject")
    public String rejectResource(@RequestParam("id") Long requestId) {
        // Retrieve the resource from the database based on the given ID
        Request req = requestServiceImpl.getRequestById(requestId);
        
        req.setStatus("Rejected");
        
        requestServiceImpl.updateRequest(req);
        return "redirect:/Employee";
    }
    
    
    
    

    
    @RequestMapping(value="/resource", method=RequestMethod.POST)
    public String updateRequest(@ModelAttribute("request") Request request, Model model ) {
    	//get resource from database
//    	
    	requestServiceImpl.updateRequest(request);
    	return "redirect:/view";
    	
    }
    
    
    
    
}
