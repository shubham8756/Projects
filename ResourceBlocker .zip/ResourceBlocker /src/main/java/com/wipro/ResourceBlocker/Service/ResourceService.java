package com.wipro.ResourceBlocker.Service;



import com.wipro.ResourceBlocker.Entity.Resource;


public interface ResourceService {
//	 Resource getAllResourcesByResourceId();
		
	
		
	public Resource deleteResource(Long id);
			
     Resource save(Resource resource);
     
     Resource getResourceById(Long id);
     Resource updateResource(Resource resource);
     
     
}
