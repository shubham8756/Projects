package com.wipro.ResourceBlocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan("com.wipro.ResourceBlocker.entity")

public class ResourceBlockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceBlockerApplication.class, args);
	}

}
