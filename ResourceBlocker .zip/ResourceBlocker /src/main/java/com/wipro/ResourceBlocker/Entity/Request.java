package com.wipro.ResourceBlocker.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Request {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String Ename;
	private String rname;

	private String rtype;
    
	@Column(unique = true)
    private String resId;
		
	private String location;

	private int quantity;
	private String status;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getRtype() {
		return rtype;
	}

	public void setRtype(String rtype) {
		this.rtype = rtype;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public String getResId() {
		return resId;
	}

	public void setResId(String resId) {
		this.resId = resId;
	}



	public Request(Long id, String Ename, String rname, String rtype, String resId, String location, int quantity, String status) {
		super();
		this.id = id;
		this.Ename = Ename;
		this.rname = rname;
		this.rtype = rtype;
		this.resId = resId;
		this.location = location;
		this.quantity = quantity;
		this.status = status;
	}

	
	public Request() {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEname() {
		return Ename;
	}

	public void setEname(String Ename) {
		this.Ename = Ename;
	}

}
