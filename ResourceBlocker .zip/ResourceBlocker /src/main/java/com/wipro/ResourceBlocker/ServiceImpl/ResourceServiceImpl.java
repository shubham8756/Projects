package com.wipro.ResourceBlocker.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.ResourceBlocker.Entity.Resource;
import com.wipro.ResourceBlocker.Repository.ResourceRepository;
import com.wipro.ResourceBlocker.Service.ResourceService;

@Service
public class ResourceServiceImpl implements ResourceService{


	

	@Autowired
    ResourceRepository resourceRepository;


    
	@Override
	public Resource save(Resource resource) {
		// TODO Auto-generated method stub
		return resourceRepository.save(resource);
	}

	public List<Resource> getAllResource(){
		return resourceRepository.findAll();
	}

//	public Resource getResourceById(Long resourceId) {
//		// TODO Auto-generated method stub
//		return resourceRepository.findById(resourceId);
//	}

	public Resource deleteResource(Long id) {
		// TODO Auto-generated method stub
		resourceRepository.deleteById(id);;
		return null;
	}

	@Override
	public Resource getResourceById(Long id) {
		
		return resourceRepository.findById(id).get();
	}

	@Override
	public Resource updateResource(Resource resource) {
		
		return resourceRepository.save(resource);
	}

	

	public Resource findByResId(String resId) {
		
		return resourceRepository.findByResId(resId);
	}
	


	
	}


