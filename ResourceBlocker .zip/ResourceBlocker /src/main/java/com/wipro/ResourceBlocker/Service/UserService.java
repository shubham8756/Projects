package com.wipro.ResourceBlocker.Service;

import com.wipro.ResourceBlocker.Entity.User;

public interface UserService {
	
	
	
User getUser(String email);
	
	void save(User user);
	

}
