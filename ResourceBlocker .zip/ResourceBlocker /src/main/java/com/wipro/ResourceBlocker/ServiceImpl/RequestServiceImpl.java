package com.wipro.ResourceBlocker.ServiceImpl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.ResourceBlocker.Entity.Request;

import com.wipro.ResourceBlocker.Repository.RequestRepository;

import com.wipro.ResourceBlocker.Service.RequestService;


@Service
public class RequestServiceImpl implements RequestService{


	

	@Autowired
    RequestRepository requestRepository;
	
	


    


//	public Resource getResourceById(Long resourceId) {
//		// TODO Auto-generated method stub
//		return resourceRepository.findById(resourceId);
//	}

//	public Resource deleteResource(Long id) {
//		// TODO Auto-generated method stub
//		resourceRepository.deleteById(id);;
//		return null;
//	}




	@Override
	public Request deleteRequest(Long id) {
		// TODO Auto-generated method stub
		requestRepository.deleteById(id);;
		return null;
		
	}






	public List<Request> getAllRequest() {
		// TODO Auto-generated method stub
		return requestRepository.findAll();
	}






	public Request getRequestById(Long id) {
		// TODO Auto-generated method stub
		return requestRepository.findById(id).get();
	}






	@Override
	public void updateRequest(Request request) {
		
		 requestRepository.save(request);
	}






	
	
//	@Override
//	public Request updateRequest(Request request) {
//		
//		return requestRepository.save(request);
//	}






}




	
	


