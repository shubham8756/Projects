package com.wipro.ResourceBlocker.Service;



import com.wipro.ResourceBlocker.Entity.Request;




public interface RequestService {
//	 Resource getAllResourcesByResourceId();
		
	
		
	public Request deleteRequest(Long id);

	void updateRequest(Request request);
			

     
}
