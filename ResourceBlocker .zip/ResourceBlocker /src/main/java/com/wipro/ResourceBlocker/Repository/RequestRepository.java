package com.wipro.ResourceBlocker.Repository;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.ResourceBlocker.Entity.Request;




@Repository
public interface RequestRepository extends JpaRepository<Request, Long>{

//	Request deleteResource(Long id);
//	Resource getResourceById(Long id);
	

}
