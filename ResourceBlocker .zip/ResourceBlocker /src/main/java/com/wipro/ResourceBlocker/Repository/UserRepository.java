package com.wipro.ResourceBlocker.Repository;

import org.springframework.stereotype.Repository;

import com.wipro.ResourceBlocker.Entity.User;

import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface UserRepository extends JpaRepository<User, Long>{
	User findByEmail(String email);
	

}
