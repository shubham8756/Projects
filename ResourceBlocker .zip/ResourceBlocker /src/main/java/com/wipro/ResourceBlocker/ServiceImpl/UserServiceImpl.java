package com.wipro.ResourceBlocker.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.ResourceBlocker.Entity.User;
import com.wipro.ResourceBlocker.Repository.UserRepository;
import com.wipro.ResourceBlocker.Service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public void save(User user) {
		userRepository.save(user);
	}
	
	@Override
	public User getUser(String email) {
		User user=userRepository.findByEmail(email);
		return user;
	}

	

}
