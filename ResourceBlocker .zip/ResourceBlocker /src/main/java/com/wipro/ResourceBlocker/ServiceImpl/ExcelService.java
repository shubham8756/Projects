package com.wipro.ResourceBlocker.ServiceImpl;


import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.ResourceBlocker.Entity.Request;
import com.wipro.ResourceBlocker.Repository.RequestRepository;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class ExcelService {
	@Autowired
	private RequestRepository requestRepo;
//	@Autowired
//	private Request request;

	public void generateExcel(HttpServletResponse response) throws Exception {

		List<Request> requests = requestRepo.findAll();

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Requests Info");
HSSFRow row = sheet.createRow(0);

		
		row.createCell(3).setCellValue("Requests");
		 row = sheet.createRow(1);

		
		row.createCell(0).setCellValue("E Name");
		row.createCell(1).setCellValue("Resource Name");
		row.createCell(2).setCellValue("Resource Type");
		row.createCell(3).setCellValue("Quantity");
		row.createCell(4).setCellValue("Location");
		row.createCell(5).setCellValue("Status");

		int dataRowIndex = 2;

		for (Request request : requests) {
			HSSFRow dataRow = sheet.createRow(dataRowIndex);
			dataRow.createCell(0).setCellValue(request.getEname());
			dataRow.createCell(1).setCellValue(request.getRname());
			dataRow.createCell(2).setCellValue(request.getRtype());
			dataRow.createCell(3).setCellValue(request.getQuantity());
			dataRow.createCell(4).setCellValue(request.getLocation());
			dataRow.createCell(5).setCellValue(request.getStatus());
			
			dataRowIndex++;
		}

		ServletOutputStream ops = response.getOutputStream();
		workbook.write(ops);
		workbook.close();
		ops.close();

	}

}

